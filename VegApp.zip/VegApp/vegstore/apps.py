from django.apps import AppConfig


class VegstoreConfig(AppConfig):
    name = 'vegstore'
