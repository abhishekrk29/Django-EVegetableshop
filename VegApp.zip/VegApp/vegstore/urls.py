"""VegApp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .middlewares.auth import  auth_middleware
from .views.views import index
from .views.views import blog
from .views.views import aboutus
from .views.signup import Signup
from .views.login import Login, Logout
from .views.profile import Profile,EditProfile,EditProfileSuccess
from .views.vegetables import Vegetables
from .views.fruits import Fruits
from .views.dairy import Dairy
from .views.cart import Cart
from .views.checkout import CheckOut
from .views.orders import OrderView
from .views.vender import Venders

urlpatterns = [
    path('', index, name='homepage'),
    path('blog/',blog, name='blog'),
    path('aboutus/',aboutus, name='aboutus'),
    path('vegetables/',Vegetables.as_view(), name='vegetables'),
    path('fruits/', Fruits.as_view(), name='fruits'),
    path('dairy/', Dairy.as_view(), name='dairy'),
    path('signup/', Signup.as_view() , name='signup'),
    path('login/', Login.as_view(), name='login'),
    path('logout/', auth_middleware(Logout) , name='logout'),
    #path('mainindex/',auth_middleware(mainpage),name='mainindex'),
    path('profile/',auth_middleware(Profile.as_view()) ,name='profile'),
    path('editprofile/',auth_middleware(EditProfile.as_view()) ,name='editprofile'),
    path('cart/', auth_middleware(Cart.as_view()) , name='cart'),
    path('checkout/', CheckOut.as_view() , name='checkout'),
    path('orders/', auth_middleware(OrderView.as_view()), name='orders'),
    path('vendor/', Venders.as_view(), name='vendor'),
    path('editprofile/success',auth_middleware(EditProfileSuccess.as_view()) ,name='editprofilesuccess'),
]
