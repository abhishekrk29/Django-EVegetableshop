from django.shortcuts import render, redirect ,HttpResponse ,HttpResponseRedirect
from django.contrib.auth.hashers import make_password
from vegstore.models.customer import Customer
from django.views import View
from django.contrib.sessions.models import Session

class Profile(View):
    def get(self,request):
        email = request.session.get('email')
        customer = Customer.get_customer_by_email(email)
        value = { 
                'first_name': customer.first_name,
                'last_name': customer.last_name,
                'phone': customer.phone,
                'email': customer.email,
                'gender': customer.gender,
                'address':customer.address,
                'city':customer.city,
                'pincode':customer.pincode  
                }
        return render(request,'profile.html',{'values':value})
    
class EditProfileSuccess(View):
    def get(self, request):
        return render(request,'editprofilesuccess.html')
        
class EditProfile(View):
    def get(self, request):
        email = request.session.get('email')
        customer = Customer.get_customer_by_email(email)
        value = { 
            'first_name': customer.first_name,
            'last_name': customer.last_name,
            'phone': customer.phone,
            'email': customer.email,
            'gender': customer.gender,
            'address':customer.address,
            'city':customer.city,
            'pincode':customer.pincode   
            }
        data= {
            'values':value,
        }
        return render(request,'editprofile.html',data)

    def post(self, request):
        postData = request.POST
        first_name = postData.get('first_name')
        last_name = postData.get('last_name')
        phone = postData.get('phone')
        email = postData.get('email')
        gender = postData.get('gender')
        address = postData.get('address')
        city = postData.get('city')
        pincode = postData.get('pincode')
        customer=Customer.get_customer_by_email(email)
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
            'gender': gender,
            'address':address,
            'city': city,
            'pincode':pincode  
        }
        error_message = None
        customer.first_name=first_name
        customer.last_name=last_name
        customer.phone=phone
        customer.gender=gender
        customer.address=address
        customer.city=city
        customer.pincode=pincode
        error_message = self.validateCustomer(customer)
        if not error_message:
            print("hello")
            print(first_name, last_name, phone, email, address,gender,city,pincode)
            customer.register()
            return redirect('editprofilesuccess')
        else:
            success=0
            print("hiii")
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'editprofile.html', data)

    def validateCustomer(self, customer):
        error_message = None;
        if (not customer.first_name):
            error_message = "First Name Required !!"
        elif len(customer.first_name) <= 2:
            error_message = 'First Name must be 3 char long or more'
        elif not customer.last_name:
            error_message = 'Last Name Required'
        elif len(customer.last_name) <= 2:
            error_message = 'Last Name must be 3 char long or more'
        elif not customer.phone:
            error_message = 'Phone Number required'
        elif len(customer.phone) != 10:
            error_message = 'Phone Number must be 10 char Long'
        elif len(customer.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(customer.email) < 5:
            error_message = 'Email must be 5 char long'
        elif not customer.gender:
            error_message = 'Gender required'
        elif not customer.address:
            error_message = 'Address required'
        elif not customer.city:
            error_message = 'City required'
        elif len(customer.city) <=2:
            error_message = 'City Name must be 3 char long'
        elif not customer.pincode:
            error_message = 'Pincode required'       
        return error_message