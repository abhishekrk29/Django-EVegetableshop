from django.shortcuts import render , redirect , HttpResponseRedirect ,HttpResponse
from vegstore.models.product import Product
from vegstore.models.category import Category
from vegstore.models.customer import Customer
from django.views import View
from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import  check_password
from django.contrib.sessions.models import Session

# Create your views here.
def index(request):
    return render(request,'index.html')

def blog(request):
    return render(request,'blog.html')

def aboutus(request):
    return render(request,'aboutus.html')
