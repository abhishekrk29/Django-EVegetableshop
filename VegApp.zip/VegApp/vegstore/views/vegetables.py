from django.shortcuts import render , redirect , HttpResponseRedirect ,HttpResponse
from vegstore.models.product import Product
from vegstore.models.category import Category
from vegstore.models.customer import Customer
from django.views import View
from django.contrib.sessions.models import Session

class Vegetables(View):    
    def get(self, request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart']={}
        products=Product.objects.filter(category__name='Vegetable')
        return render(request,'vegetables.html',{'products' :products})
    
    def post(self, request):
        product = request.POST.get('pid')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product]  = quantity-1
                else:
                    cart[product]  = quantity+1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart' , request.session['cart'])
        return redirect('vegetables')
    