from django.shortcuts import render, redirect
from vegstore.models.vender import Vender
from django.views import View
import re 

class Venders(View):
    def get(self, request):
        return render(request,'vendor.html')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        phone = postData.get('phone')
        email = postData.get('email')
        adhaarno= postData.get('adhaarno')
        gender = postData.get('gender')
        address= postData.get('address')
        city= postData.get('city')
        pincode =postData.get('pincode')
        # validation
        value = {
            'name': name,
            'address': address,
            'phone': phone,
            'email': email,
            'adhaarno':adhaarno,
            'gender':gender,
            'city':city,
            'pincode':pincode
        }
        error_message = None

        vender = Vender(name=name,
                        address=address,
                        phone=phone,
                        email=email,
                        gender=gender,
                        adhaarno=adhaarno,
                        city=city,
                        pincode=pincode)
        error_message = self.validateVender(vender)

        if not error_message:
            print(name,  phone, email, adhaarno,gender,address,city,pincode)
            vender.register()
            success=1
            return render(request,'vendor.html',{'success':success})
        else:
            success=0
            data = {
                'error': error_message,
                'values': value
            }
            return render(request,'vendor.html',data)

    def validateVender(self,customer):
        error_message = None;
        regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
        if (not customer.name):
            error_message = "Full Name Required !!"
        elif len(customer.name) <= 2:
            error_message = 'Full Name must be 3 char long or more'
        elif not customer.adhaarno:
            error_message = 'Adhaar Number Required !!'
        elif len(customer.adhaarno) != 12:
            error_message = 'Adhaar Number must be 12 Digit Only!!'
        elif not customer.phone:
            error_message = 'Phone Number Required !!'
        elif len(customer.phone) != 10:
            error_message = 'Phone Number must be 10 char Long'
        elif (not customer.gender):
            error_message = 'Gender Required !!'    
        elif len(customer.email) < 5:
            error_message = 'Email must be 5 char long'
        elif (re.search(regex,customer.email))==False:
            error_message = 'Email is not Valid'    
        elif customer.isCheck():
            error_message = 'Email Address Already Registered..'
        return error_message