from django.db import  models
from django.core.validators import MinLengthValidator

class Vender(models.Model):
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    adhaarno = models.CharField(max_length=500)
    gender = models.CharField(max_length=10)
    address = models.CharField(max_length=500)
    city=models.CharField(max_length=50)
    pincode = models.CharField(max_length=6)

    def register(self):
        self.save()

    @staticmethod
    def get_vender_by_email(email):
        try:
            return Vender.objects.get(email=email)
        except:
            return False
       
    def isCheck(self):
        if Vender.objects.filter(email = self.email):
            return True
        return  False


